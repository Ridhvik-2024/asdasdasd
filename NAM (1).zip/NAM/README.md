# NAM — Navigation Assistance for Mars

NAM is a static HTML/CSS/JavaScript frontend using CesiumJS and public NASA/JPL
Mars Trek imagery. The map layers are curated from the NASA/JPL Mars Trek
resource map: <https://trek.nasa.gov/mars/>.

## Run locally

1. Extract the ZIP.
2. Open the `NAM` folder in VS Code.
3. Open a terminal in that folder and run:

```bash
py -m http.server 8000
```

4. Open `http://localhost:8000` in your browser.

Do not open `index.html` directly as `file://`. CesiumJS and NASA/JPL imagery are loaded from external services, so an internet connection is required.

## Deploy to Netlify

1. Sign in at https://app.netlify.com/.
2. Choose **Add new site** → **Deploy manually**.
3. Extract the ZIP on your computer.
4. Drag the `NAM` folder (the folder containing `index.html`) into the Netlify deploy area.
5. Wait for the upload to finish. Netlify will provide a public website URL.

No build command is required. The publish directory is the frontend root (`NAM/`). If configuring a Git-based deploy, use an empty build command and set the publish directory to `NAM`.

## Branding

- The application is branded **NAM — Navigation Assistance for Mars**.
- The supplied NAM logo mark (Mars disc with a planned traverse route) sits in the top-left corner of both the homepage and the atlas; it also serves as the favicon (`assets/nam-logo.svg`).
- All outdated MARSWALK branding has been removed from the visible interface. Internal identifiers (tile IDs, place IDs, CSS class names) are unchanged.

## Home experience

- Cinematic NAM introduction with the locked charcoal, graphite, copper and sandstone palette, a sparse procedural starfield and film grain.
- Delayed heading/description/button reveal and a smooth planet arrival animation.
- Oversized, unframed GPU-rendered WebGL Mars globe using the **same Mars as the atlas**: the locally bundled texture (`assets/mars-surface-texture.jpg`, 4096 × 2048) is the Viking MDIM 2.1 global colour mosaic stitched from the very tile service the CesiumJS globe streams, so the homepage planet and the atlas globe share the same OG colours and geology — with four times the detail of the earlier texture (`mars-surface-texture.png` is kept as a graceful fallback). The planet is shown **fully lit with no heavy dark vignette** in the raw MDIM palette: soft depth shading keeps the whole disc visible, texture-driven relief shading makes the real craters and canyons catch the light, procedural crater rings and regolith add fine surface variation, and the real polar frost caps come through from the mosaic.
- Spec-driven Mars movement on the homepage: continuous slow rotation (0.105 rad/s), cursor-responsive orientation and tilt with **release momentum** (decaying at the reference spec's `inertiaSpin 0.84`), a controlled follow rate (`maximumMovementRatio 0.05`), hover magnification, and **wheel / trackpad-pinch zoom** using the atlas's rAF-batched exponential zoom curve (`exp(deltaY × k)`, delta-mode normalised, `|ΔY| ≥ 0.01`) with `inertiaZoom 0.65` inertial glide.
- **Focus hand-off**: selecting the planet or **ENTER THE ATLAS** never opens into a different Mars. Every other UI element recedes, the same live homepage planet floats from the right of the screen into the centre as a smaller globe (still rotating, colour-matched), and only then does the atlas fade in around it — the globe glides from the wide establishing shot into the canonical overview while the homepage Mars crossfades into the identical atlas globe.
- Responsive desktop and mobile layouts, with reduced-motion support.

The homepage hero is a real WebGL-rendered sphere using a GPU fragment shader and the locally bundled Viking MDIM 2.1 global colour mosaic (`assets/mars-surface-texture.jpg`, stitched at 4096 × 2048 from the same tile service the atlas uses, so front and back are the same Mars; the earlier `assets/mars-surface-texture.png` remains as a fallback). A CSS fallback is retained for browsers without WebGL.

## Existing atlas functionality

- Full-screen globe with locally generated six-face star skybox.
- Viking MDIM 2.1 global colour mosaic as the default basemap; MOLA colour hillshade as an alternate. If the primary NASA tile service does not respond (blocked network, offline demo), the atlas switches to the **same bundled Viking mosaic the homepage planet uses** — front and back always show the same Mars.
- Mars Trek equirectangular overlays, base-map switching and opacity controls.
- Custom XYZ / REST WMTS tile URL input.
- Data catalogue linking to the Mars Trek resource map, NASA/JPL, PDS, USGS, THEMIS, HiRISE and rover-image sources.
- Location search, featured locations, point inspection and route sketching.
- Map image export (`nam-map-view.png`) and GeoJSON traverse export (`nam-traverse.geojson`).

## Map services and scientific limitations

The layers are curated from the NASA/JPL Mars Trek equirectangular service catalogue (`https://trek.nasa.gov/tiles/apidoc/trekAPI.html?body=mars`). The default basemap is `Mars_Viking_MDIM21_ClrMosaic_global_232m`, a global Viking colour mosaic listed in the Mars Trek catalogue. It uses the Mars 2000 geographic/equirectangular grid.

The base globe uses Mars 2000 equatorial and polar radii (3,396,190 m and 3,376,200 m). Connected overlay tile templates use the Mars Trek equirectangular services and a geographic tiling scheme. A custom layer must use Mars equirectangular coordinates (EPSG:104905) and an XYZ-style template containing `{z}`, `{y}` and `{x}`.

The globe is a textured Mars ellipsoid, not a high-resolution terrain mesh. Mission markers are regional reference points, not current rover coordinates or landing ellipses. Route length is an approximate spherical surface-distance calculation; it does not account for terrain elevation, slope, obstacles, energy, communications, radiation, thermal conditions or mobility constraints. It must not be described as a safe route.

## Files

- `index.html` — entry experience and atlas interface
- `styles.css` — NAM visual system and responsive layout
- `home.js` — WebGL Mars hero renderer (full-lit planet shader, texture relief, starfield, wheel zoom, pointer interaction, reduced-motion handling and entry transition)
- `assets/mars-surface-texture.png` — locally bundled panoramic Mars surface texture for the homepage hero
- `assets/nam-logo.svg` — NAM logo mark and favicon
- `app.js` — Cesium globe, NASA imagery, layer manager, data catalogue and traversal tools

## Notes

- CesiumJS and imagery are external services. Their availability, CORS policy and terms are controlled by their providers.
- The Python/C++ NAM backend is not included in this static frontend ZIP. Backend API features require separate hosting and integration.
