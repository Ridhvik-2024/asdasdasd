# Person B — Spatial Engine & Planetary Geometry Fixes

Scope: `app/terrain.py`, `app/mars.py`, `app/routers/walkview.py`,
`tests/test_submission_spatial.py`. No other files were touched.

## Result

- **Full suite: 59/59 pass** (48 pre-existing + 11 new spatial tests).
- The 11 new tests are meaningful: **7 fail on the original pre-fix code**
  (all 5 required behaviours + 2 related guards) and all 11 pass after the
  fixes. The other 4 are positive safety-nets that hold both before and after.

## The five must-fix items

### 1. Procedural terrain continuity — `terrain.py::_detail()`

**Before:** `_detail()` hashed a fresh CRC32 seed from the rounded `(lat, lon)`
(`"%.3f|%.3f"`) and then evaluated `_fbm` at a *fixed* lattice position
`(77.0, 133.0)`. The only thing that varied between coordinates was the hash
offset, so two points 60 m apart could swing by the full ±amplitude (~140 m),
and points inside the same 0.001° cell were identical then jumped randomly at
the cell boundary — a discontinuous staircase, not a surface.

**After:** added `_detail_noise(lat, lon, seed)` — value-noise fBm sampled at
the **real geographic position** with smoothstep interpolation, so adjacent
coordinates blend smoothly. Longitude is sampled on a cylindrical lattice that
**wraps every 360°**, so the detail field is also continuous across the 0/360
seam. Latitude uses a linear (clamped) lattice. Determinism is preserved: same
`(lat, lon, seed)` → same value.

Measured: a 60 m step now changes detail by ~0.03 m (was up to ~140 m); a 6 m
step by ~0.003 m.

### 2. Longitude interpolation at the 0°/360° boundary — `terrain.py::elev()`

**Before:** `xi = clip(searchsorted(LONS, lon) - 1, 0, nlon - 2)`. For a
longitude just below 360° (e.g. 359.9), `searchsorted` returned `nlon`, the
clip forced `xi = nlon - 2`, and `wx` exceeded 1 → **extrapolation** past the
final grid column instead of wrapping to column 0. The same happened at lon 0
(`wx` went negative).

**After:** longitude is indexed on the **periodic** lattice:
`fx = ((lon - LONS[0]) / dlon) % nlon`, `xi = floor(fx) % nlon`,
`xj = (xi + 1) % nlon`. A point at 359.9 now interpolates between the last
column (359.75) and the wrapped first column (0.25 = 360.25). Latitude is
clamped to valid rows (no pole extrapolation). `slope()` was given the same
periodic indexing for consistency. Interior sampling is byte-for-byte
unchanged (Olympus/Hellas landmarks verified).

### 3. Antimeridian bounding boxes — `terrain.py::bbox_stats()`

**Before:** `if min_lon > max_lon: min_lon, max_lon = max_lon, min_lon` — a
small box crossing 0° (e.g. 350° → 10°, true span 20°) was swapped into a
340° span covering nearly the whole planet.

**After:** longitudes are normalised to 0–360; when `min_lon > max_lon` the
box is recognised as **crossing the antimeridian** and the selected region is
the union of `[min_lon, 360)` and `[0, max_lon]`, concatenated along the
longitude axis. A new `crosses_antimeridian` flag makes the wrap explicit. The
returned stats are verified against a manual grid union in the test, and the
crossing box is confirmed ~17× smaller than the genuinely-large 340° box.

### 4. Polygon area across the antimeridian — `mars.py::poly_area_km2()`

**Before:** the spherical shoelace used raw `norm_lon` longitudes, so a polygon
spanning 359° → 1° took `Δλ = 1 - 359 = -358°` and reported an area of
**~2.46 × 10⁶ km²** for what is really a 2° × 2° box (~13,800 km²).

**After:** longitudes are **unwrapped** so each consecutive edge uses the short
angular difference (`Δ = ((Δ + 180) % 360) - 180`), then the shoelace runs on
the unwrapped series. The crossing box now reports **13,800.9 km²**, matching a
non-crossing 2° × 2° reference at the same latitude to within floating-point
epsilon. Non-crossing polygons are unaffected (verified against the Phase 1
measurement gate).

### 5. Walk View terrain provenance — `routers/walkview.py::walk_init()`

**Before:** `terrain_relief.source` was `"MOLA-derived terrain patch (Walk View
mesh endpoint)"` — claiming measured MOLA data while the engine actually
serves synthetic terrain.

**After:** `"NAM synthetic terrain patch (Walk View mesh endpoint) [SIM]"` with
a note explaining it is demo-synthetic-grid + procedural detail, not measured
MOLA, and pointing to the documented production swap (MOLA MEGDR 4 ppd /
HiRISE DTMs). This matches the honesty contract already encoded in
`terrain.TerrainEngine.prov()`.

## Files

| Path | Change |
| --- | --- |
| `app/terrain.py` | new `_detail_noise()`; rewritten `_detail()`, `elev()`, `slope()`, `bbox_stats()` |
| `app/mars.py` | longitude unwrap in `poly_area_km2()` |
| `app/routers/walkview.py` | corrected `terrain_relief` provenance string |
| `tests/test_submission_spatial.py` | new — 11 tests covering all five behaviours |
| `*.diff` | unified diffs vs. the original uploaded files |

## Run

```bash
cd <repo>
python -m pytest tests/test_submission_spatial.py -v   # 11 passed
python -m pytest tests/ -q                              # 59 passed (no regressions)
```

## Notes / assumptions

- Longitude convention is unchanged: east 0–360 (per `app/integrity.py`).
- The detail noise is longitude-periodic and latitude-continuous; it is **not**
  latitude-periodic (poles are a boundary), which is acceptable for a local
  relief texture and matches the existing "no pole extrapolation" intent.
- `bbox_stats` gained one additive field (`crosses_antimeridian`); existing
  callers (`jev/tools`, `measurements`, `terrain`/`science` routers) consume
  the dict by key and are unaffected.
- Persons A and C own `routing.py`, `missions.py`, `jev/*`, etc.; those files
  were not modified. `routing.py` calls `T.elev(...)` per point, and the
  interior behaviour of `elev()` is preserved, so routing is unaffected.
