"""JEV endpoints: 24-tool registry, SSE chat with tool-activity trace,
explain-view, benchmark."""
import asyncio
import json

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .. import db
from ..jev import llm, router as jev_router
from ..jev.tools import TOOLS, run_tool

router = APIRouter(prefix="/jev", tags=["jev"])


@router.get("/tools")
def tools_list():
    return {"count": len(TOOLS), "tools": TOOLS,
            "note": "16 tools carried from NAM v1 + 8 Phase 3 tools; JSON-schema-constrained, fail closed"}


class ChatIn(BaseModel):
    message: str
    map_context: dict = {}


def _sse(obj):
    return "data: %s\n\n" % json.dumps(obj, ensure_ascii=False)


@router.post("/chat")
async def chat(c: ChatIn):
    """SSE stream: plan -> tool activity trace -> streamed answer -> done.

    With a local LLM configured the model plans and writes; otherwise the
    deterministic intent router plans and the composer writes. Both paths
    emit the same event protocol."""
    db.ex("INSERT INTO chat_logs (role,content) VALUES (?,?)", ("user", c.message))
    plan = None
    composer = None
    llm_planned = False

    async def make_gen():
        nonlocal plan, composer, llm_planned
        yield _sse({"type": "start", "engine": llm.describe()})
        planned = llm.plan_with_llm(c.message, c.map_context)
        invocations = []
        if planned and planned.get("steps"):
            llm_planned = True
            steps = planned["steps"]
        else:
            plan, composer = jev_router.plan_for(c.message, c.map_context)
            steps = plan.steps
        # Execute the plan. Every invocation is preserved separately (its own
        # id + its own arguments) instead of results[tool] = res, which let a
        # repeated execution overwrite the first result. A failing step records
        # its error and never blocks independent subsequent tools.
        for ev in execute_steps(steps, {"map_context": c.map_context}, trace=invocations):
            yield _sse(ev)
        view = _build_view(invocations)
        failure_note = _failure_note(invocations)
        if llm_planned:
            answer = llm.chat_with_llm(c.message, c.map_context, _llm_trace(invocations)) or \
                "The local model could not produce an answer; tool outputs above are grounded and complete."
            citations = ["tool invocations: " + ", ".join(inv["id"] for inv in invocations)]
            intents = planned.get("intents", [])
        else:
            answer = composer(view) or ""
            citations = [s for s in _citations_from(invocations)]
            intents = plan.intents
        if failure_note:
            # partial failure: the answer must honestly acknowledge missing information
            answer = "%s\n%s" % (answer, failure_note)
        # stream the answer in small chunks (token-stream shim; real LLM streams natively)
        chunks = [answer[i:i + 90] for i in range(0, len(answer), 90)]
        for chn in chunks:
            yield _sse({"type": "delta", "text": chn})
            await asyncio.sleep(0.01)
        db.ex("INSERT INTO chat_logs (role,content) VALUES (?,?)", ("jev", answer))
        yield _sse({"type": "done", "reply": answer, "citations": citations,
                    "intents": intents, "engine": "local-llm" if llm_planned else "deterministic-router"})

    return StreamingResponse(make_gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


class ExplainIn(BaseModel):
    map_context: dict = {}


@router.post("/explain")
def explain(e: ExplainIn):
    return jev_router.explain_view({"map_context": e.map_context})


@router.get("/benchmark")
def benchmark():
    return llm.benchmark()


@router.get("/logs")
def logs(limit: int = 20):
    rows = db.q("SELECT ts,role,content FROM chat_logs ORDER BY id DESC LIMIT ?", (min(limit, 100),))
    return {"logs": rows}


# ------------------------------------------------------------ execution core

_SLIM_CHAR_BUDGET = 4000
_TRUNCATION_MARK = "...[truncated to keep valid JSON]"


def _json_size(value):
    """Serialised length of *value*, or None when it is not JSON-serialisable."""
    try:
        return len(json.dumps(value, ensure_ascii=False))
    except (TypeError, ValueError):
        return None


def _slim_value(value, budget=_SLIM_CHAR_BUDGET):
    """Structured truncation of any JSON-serialisable value.

    The old implementation sliced the serialised JSON text and tried to
    re-balance the remainder, which can cut inside a string or escape and
    produce malformed JSON (or crash on json.loads). Instead the structure is
    trimmed: dicts key by key, lists item by item, and only whole strings are
    cut - a cut string is still valid JSON. Truncation is marked so consumers
    know data was reduced. The result always serialises and reparses cleanly."""
    try:
        budget = max(int(budget), 64)
    except (TypeError, ValueError):
        budget = _SLIM_CHAR_BUDGET
    size = _json_size(value)
    if size is None:
        return _TRUNCATION_MARK
    if size <= budget:
        return value
    if isinstance(value, dict):
        out, left, kept = {}, budget - 2, 0
        for k, v in value.items():
            key = k if isinstance(k, str) else str(k)
            piece = _slim_value(v, max(64, left - len(json.dumps(key, ensure_ascii=False)) - 2))
            need = _json_size({key: piece})
            if kept > 0 and (need or 0) - 2 > left:
                out["_truncated"] = "%d of %d keys omitted" % (len(value) - kept, len(value))
                return out
            out[key] = piece
            left -= need
            kept += 1
        return out
    if isinstance(value, (list, tuple)):
        out, left = [], budget - 2
        for item in value:
            piece = _slim_value(item, max(64, left))
            need = _json_size(piece)
            if need is None or need > left:
                out.append(_TRUNCATION_MARK)
                return out
            out.append(piece)
            left -= need + 1
        return out
    if isinstance(value, str):
        keep = max(0, budget - len(_TRUNCATION_MARK) - 2)
        return value[:keep] + _TRUNCATION_MARK
    if isinstance(value, bytes):
        return _TRUNCATION_MARK
    return value        # numbers / bools / None are always kept whole


def _slim(results, max_chars=_SLIM_CHAR_BUDGET):
    """Truncate a {key: result} mapping to a bounded, always-valid-JSON view."""
    return {k: _slim_value(v, max_chars) for k, v in (results or {}).items()}


def _next_invocation_id(step, counters, taken):
    """Unique id per invocation: the plan-provided id or <tool>#<n> by
    execution order per tool; never two invocations under one id."""
    tool = step["tool"]
    counters[tool] = counters.get(tool, 0) + 1
    inv_id = step.get("id") or ("%s#%d" % (tool, counters[tool]))
    candidate, suffix = inv_id, 1
    while candidate in taken:          # safety net against colliding plan ids
        suffix += 1
        candidate = "%s#%d" % (inv_id, suffix)
    taken.add(candidate)
    return candidate


def execute_steps(steps, ctx, trace=None):
    """Execute tool-call steps in order, preserving every invocation separately.

    Yields SSE-ready event dicts (tool_start before each run, tool_result
    after). Each executed step is appended to *trace* as
    {"id", "tool", "args", "result", "ok"}, so running the same tool twice
    keeps two records with their own ids and arguments instead of the second
    overwriting the first. A failed step preserves its error, never overwrites
    a successful result, and never blocks independent subsequent tools."""
    counters, taken = {}, set()
    for step in steps:
        step = step or {}
        tool = step.get("tool")
        if not tool:
            continue
        args = step.get("args") or {}
        inv_id = _next_invocation_id(step, counters, taken)
        yield {"type": "tool_start", "id": inv_id, "tool": tool, "args": args}
        try:
            res = run_tool(tool, args, ctx or {})
        except Exception as e:      # hard guarantee: one crash never kills the run
            res = {"error": "tool_execution_failed",
                   "detail": "%s: %s" % (type(e).__name__, e)}
        ok = not _is_error(res)
        yield {"type": "tool_result", "id": inv_id, "tool": tool, "ok": ok,
               "error": None if ok else res.get("error"),
               "keys": [k for k in res.keys()][:6] if isinstance(res, dict) else []}
        if trace is not None:
            trace.append({"id": inv_id, "tool": tool, "args": args,
                          "result": res, "ok": ok})


def _is_error(res):
    return isinstance(res, dict) and "error" in res


def _build_view(invocations):
    """Composer-facing results view.

    Results are addressable by their unique invocation id
    ("analyze_terrain#1", "analyze_terrain#2", ...). For backwards
    compatibility each tool name is also an alias: it resolves to the first
    successful invocation of that tool, or to its first invocation when every
    run failed - so a late failure can never overwrite a successful result."""
    view, best = {}, {}
    for inv in invocations:
        view[inv["id"]] = inv["result"]
        cur = best.get(inv["tool"])
        if cur is None or (not cur["ok"] and inv["ok"]):
            best[inv["tool"]] = inv
    for tool, inv in best.items():
        view[tool] = inv["result"]
    return view


def _failure_note(invocations):
    """Honest acknowledgement of partial failure: missing data stays missing."""
    failed = [i for i in invocations if not i["ok"]]
    if not failed:
        return None
    parts = []
    for f in failed[:3]:
        detail = ""
        if isinstance(f["result"], dict):
            detail = str(f["result"].get("detail") or f["result"].get("error") or "")
        parts.append("%s: %s" % (f["id"], detail or "failed"))
    more = " (+%d more)" % (len(failed) - 3) if len(failed) > 3 else ""
    return ("Note: %d of %d tool call(s) failed [%s%s]; that information is missing "
            "from this answer and nothing was invented to fill the gap. Every other "
            "statement above comes from successful, grounded tool outputs."
            % (len(failed), len(invocations), "; ".join(parts), more))


def _llm_trace(invocations):
    """Per-invocation trace for the model: id, tool, args and result-or-error,
    with each result structurally slimmed so the prompt stays valid JSON."""
    entries = []
    for inv in invocations:
        e = {"id": inv["id"], "tool": inv["tool"], "args": inv["args"], "ok": inv["ok"]}
        if inv["ok"]:
            e["result"] = _slim_value(inv["result"], _SLIM_CHAR_BUDGET)
        else:
            e["error"] = inv["result"] if isinstance(inv["result"], dict) else str(inv["result"])
        entries.append(e)
    return entries


def _citations_from(invocations):
    cits = []
    for inv in invocations:
        res = inv.get("result") if isinstance(inv, dict) else None
        if not isinstance(res, dict):
            continue
        p = res.get("provenance") or res.get("anchor")
        if p:
            cits.append("%s: %s" % (inv.get("tool", "?"),
                                    p if isinstance(p, str) else p.get("source", "")))
        if "observations" in res:
            cits += [o["evidence"]["citation"] for o in res["observations"][:3]
                     if "evidence" in o]
    return cits or ["NAM deterministic services [SIM]"]
